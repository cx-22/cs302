Compile using the given Makefile "make"

Test the 2 real sequences by passing it into the exe "./solution < s1ands2.txt"

The result will be 965
